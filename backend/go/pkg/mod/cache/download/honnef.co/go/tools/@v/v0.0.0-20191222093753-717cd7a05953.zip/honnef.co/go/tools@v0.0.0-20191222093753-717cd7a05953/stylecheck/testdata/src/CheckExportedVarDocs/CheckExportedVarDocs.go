package pkg

// Whatever
var a int

// Whatever // want `should be of the form`
var B int

// Whatever
var (
	// Whatever
	C int
)

func fn() {
	// Whatever
	var D int
	_ = D
}
