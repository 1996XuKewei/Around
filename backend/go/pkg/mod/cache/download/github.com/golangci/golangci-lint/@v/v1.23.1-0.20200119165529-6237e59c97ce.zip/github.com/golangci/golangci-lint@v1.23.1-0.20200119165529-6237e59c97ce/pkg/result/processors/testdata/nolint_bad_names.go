package testdata

var nolintUnknownLinter1 bool // nolint:bad1,deadcode,varcheck,megacheck

//nolint:bad2,deadcode,megacheck
func nolintUnknownLinter2() {

}
