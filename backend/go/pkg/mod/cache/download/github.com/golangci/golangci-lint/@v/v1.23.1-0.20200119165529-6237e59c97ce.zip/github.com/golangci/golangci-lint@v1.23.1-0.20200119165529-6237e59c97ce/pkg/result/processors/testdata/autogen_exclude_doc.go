package testdata

// DO NOT EDIT

import "fmt"

// nolint
func PrintString(s string) {
	fmt.Printf("%s", s)
}
